import com.example.demo.FarewellService;
import com.example.demo.GreetingController;

@RunWith(SpringRunner.class)
@SpringBootTest
public class GreetingControllerTest {

    @Autowired
    private GreetingController greetingController;

    @MockBean
    private GreetingService greetingService;

    @MockBean
    private FarewellService farewellService;

    @Test
    public void testGreet() {
        // Arrange
        Mockito.when(greetingService.getGreeting()).thenReturn("Hello, Spring Boot!");

        // Act
        String result = greetingController.greet();

        // Assert
        assertEquals("Hello, Spring Boot!", result);
    }

    @Test
    public void testFarewell() {
        // Arrange
        Mockito.when(farewellService.getFarewell()).thenReturn("Goodbye, Spring Boot!");

        // Act
        String result = greetingController.farewell();

        // Assert
        assertEquals("Goodbye, Spring Boot!", result);
    }
}
