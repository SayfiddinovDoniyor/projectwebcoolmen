package com.example.demo;

public interface FarewellService {
    String getFarewell();
}
