package com.example.demo.controller;

public class Student extends Person {
    private String studentId;

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public Student(String name, int age, String address, String studentId) {
        setName(name);
        setAge(age);
        setAddress(address);
        this.studentId = studentId;
    }

    public static void main(String[] args) {
        // Creating a Student object
        Student student = new Student("Alice", 20, "456 College Ave", "S12345");

        // Print the details of the Student object
        System.out.println("Name: " + student.getName());
        System.out.println("Age: " + student.getAge());
        System.out.println("Address: " + student.getAddress());
        System.out.println("Student ID: " + student.getStudentId());
    }
}
