package com.example.demo.controller;

public class Factory {

    // Factory method to create a Person object with default values
    public static Person createPersonWithDefaults() {
        Person person = new Person();
        person.setName("Default Name");
        person.setAge(30);
        person.setAddress("Default Address");
        return person;
    }

    public static void main(String[] args) {
        // Create a Person using the factory method with default values
        Person person = Factory.createPersonWithDefaults();

        // Print out the details of the created Person object
        System.out.println("Name: " + person.getName());
        System.out.println("Age: " + person.getAge());
        System.out.println("Address: " + person.getAddress());
    }
}
