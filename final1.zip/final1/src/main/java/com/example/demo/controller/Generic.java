package com.example.demo.controller;

public class Generic<T> {
    private T object;

    public Generic(T object) {
        this.object = object;
    }
    public T getObject() {
        return object;
    }

    public static void main(String[] args) {
        Person person = new Person();
        person.setName("John");
        person.setAge(25);
        person.setAddress("123 Main St");
        Generic<Person> personGeneric = new Generic<>(person);
        System.out.println("Person Name: " + personGeneric.getObject().getName());

        Student student = new Student("Alice", 20, "456 College Ave", "S12345");

        Generic<Student> studentGeneric = new Generic<>(student);
        System.out.println("Student Name: " + studentGeneric.getObject().getName());
    }
}
