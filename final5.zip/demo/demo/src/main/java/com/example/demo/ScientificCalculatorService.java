package com.example.calculator;

import org.springframework.stereotype.Service;

@Service
public class ScientificCalculatorService implements ICalculatorService {

    @Override
    public int add(int a, int b) {
        return a + b;
    }

    @Override
    public int subtract(int a, int b) {
        return a - b;
    }

    @Override
    public int multiply(int a, int b) {
        return a * b;
    }

    @Override
    public double divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return (double) a / b;
    }

    public double squareRoot(int a) {
        return Math.sqrt(a);
    }

    public double power(int a, int b) {
        return Math.pow(a, b);
    }
}
