package com.example.demo;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class HistoryService {

    private List<String> history = new ArrayList<>();

    public void logOperation(String operation) {
        history.add(operation);
    }

    public List<String> getHistory() {
        return history;
    }
}
