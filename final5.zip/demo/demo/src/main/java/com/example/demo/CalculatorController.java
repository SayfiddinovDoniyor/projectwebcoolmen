package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CalculatorController {

    @Autowired
    @Qualifier("simpleCalculatorService")
    private ICalculatorService calculatorService;

    @Autowired
    private HistoryService historyService;

    @GetMapping("/add")
    public int add(@RequestParam int a, @RequestParam int b) {
        int result = calculatorService.add(a, b);
        historyService.logOperation("Add: " + a + " + " + b + " = " + result);
        return result;
    }

    @GetMapping("/history")
    public List<String> getHistory() {
        return historyService.getHistory();
    }
}
